from microWebSrv import MicroWebSrv
from network import LoRa
import socket
import time
print("Alive")
# ---------------------------------------------------------------------------- "address": "/dev/tty.usbmodemPy7067511"
sendlaura="nothing"
messages=[]
senderip="none"
lora = LoRa(mode=LoRa.LORA, region=LoRa.EU868)
s = socket.socket(socket.AF_LORA, socket.SOCK_RAW)
grid=""
# while True:
#     s.setblocking(True)
#     s.send("sendlaura")
# print("after laura")
@MicroWebSrv.route('/test')
def _httpHandlerTestGet(httpClient, httpResponse) :
	s.setblocking(False)
	msg=s.recv(64)
	reciverip=httpClient.GetIPAddr()
	#s.send(str(reciverip))
	print(msg)
	if msg==b'':
		print("")
	else:
		newmsg=str(msg).replace("b'","")
		newmsg=newmsg.replace("'","")
		print(newmsg)
		# print(newmsg[1])
		# senderip=newmsg[1]
		totest="FromBridge"
		if totest in newmsg :
			res_str = newmsg.replace(totest, '')
			messages.append(res_str)
	# print (messages)
	grid=""
	for vals in range(len(messages)):
		print(vals)
		myval=str(messages[vals]).split(",")
		for localval in range(len(myval)):
			# global grid
			grid+=""" <div class="grid-item">"""+str(myval[localval])+"""</div>"""

		

	content = """\
	<!DOCTYPE html>
	<html lang=en>
        <head>
        	<meta charset="UTF-8" />
			<meta http-equiv="refresh" content="2">
            <title>Lopy Receiver</title>
			<style>
.grid-container {
  display: grid;
  grid-template-columns: auto auto auto auto;
  background-color: #2196F3;
  padding: 10px;
}
.grid-item {
  background-color: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(0, 0, 0, 0.8);
  padding: 20px;
  font-size: 30px;
  text-align: center;
}
</style>
        </head>
        <body>
            <h1>Lopy Receiver</h1>

<div class="grid-container">
<div class="grid-item">Full name</div>
<div class="grid-item">Group</div>
<div class="grid-item">Danger</div>
<div class="grid-item">IP</div>
%s 
</div>
			
            <br />
			
        </body>
    </html>
	""" % grid
	httpResponse.WriteResponseOk( headers		 = None,
								  contentType	 = "text/html",
								  contentCharset = "UTF-8",
								  content 		 = content )


@MicroWebSrv.route('/test', 'POST')
def _httpHandlerTestPost(httpClient, httpResponse) :
	formData  = httpClient.ReadRequestPostedFormData()
	firstname = formData["firstname"]
	lastname  = formData["lastname"]
	s.send(str(firstname))
	print(firstname)
	content   = """\
	<!DOCTYPE html>
	<html lang=en>
		<head>
			<meta charset="UTF-8" />
            <title>TEST POST</title>
        </head>
        <body>
            <h1>TEST POST</h1>
            Firstname = %s<br />
            Lastname = %s<br />
        </body>
    </html>
	""" % ( MicroWebSrv.HTMLEscape(firstname),
		    MicroWebSrv.HTMLEscape(lastname) )
	httpResponse.WriteResponseOk( headers		 = None,
								  contentType	 = "text/html",
								  contentCharset = "UTF-8",
								  content 		 = content )


@MicroWebSrv.route('/edit/<index>')             # <IP>/edit/123           ->   args['index']=123
@MicroWebSrv.route('/edit/<index>/abc/<foo>')   # <IP>/edit/123/abc/bar   ->   args['index']=123  args['foo']='bar'
@MicroWebSrv.route('/edit')                     # <IP>/edit               ->   args={}
def _httpHandlerEditWithArgs(httpClient, httpResponse, args={}) :
	content = """\
	<!DOCTYPE html>
	<html lang=en>
        <head>
        	<meta charset="UTF-8" />
            <title>TEST EDIT</title>
        </head>
        <body>
	"""
	content += "<h1>EDIT item with {} variable arguments</h1>"\
		.format(len(args))
	
	if 'index' in args :
		content += "<p>index = {}</p>".format(args['index'])
	
	if 'foo' in args :
		content += "<p>foo = {}</p>".format(args['foo'])
	
	content += """
        </body>
    </html>
	"""
	httpResponse.WriteResponseOk( headers		 = None,
								  contentType	 = "text/html",
								  contentCharset = "UTF-8",
								  content 		 = content )

# ----------------------------------------------------------------------------

def _acceptWebSocketCallback(webSocket, httpClient) :
	print("WS ACCEPT")
	webSocket.RecvTextCallback   = _recvTextCallback
	webSocket.RecvBinaryCallback = _recvBinaryCallback
	webSocket.ClosedCallback 	 = _closedCallback

def _recvTextCallback(webSocket, msg) :
	print("WS RECV TEXT : %s" % msg)
	webSocket.SendText("Reply for %s" % msg)

def _recvBinaryCallback(webSocket, data) :
	print("WS RECV DATA : %s" % data)

def _closedCallback(webSocket) :
	print("WS CLOSED")

# ----------------------------------------------------------------------------

#routeHandlers = [
#	( "/test",	"GET",	_httpHandlerTestGet ),
#	( "/test",	"POST",	_httpHandlerTestPost )
#]

srv = MicroWebSrv(webPath='www/')
srv.MaxWebSocketRecvLen     = 256
srv.WebSocketThreaded		= False
srv.AcceptWebSocketCallback = _acceptWebSocketCallback
srv.Start()


# ----------------------------------------------------------------------------
